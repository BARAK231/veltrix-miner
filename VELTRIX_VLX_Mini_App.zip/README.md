# VELTRIX (VLX) — Telegram Mini App

A mobile-friendly Telegram mining Mini App starter.

Current points are OFF-CHAIN virtual VLX Points. They are not a live cryptocurrency and have no guaranteed price or listing.

## Mobile setup
1. Create a Telegram bot with @BotFather and get BOT_TOKEN.
2. Put this project on an HTTPS Node.js host.
3. Set APP_URL to the deployed URL.
4. Set the bot's Main Mini App/Menu Button URL in @BotFather.
5. Open the bot and tap OPEN VELTRIX MINER.

Features:
- VLX Points mining
- individual balances
- claim/accrual
- boost
- referral bonus
- wallet address
- PENDING withdrawal requests
- admin withdrawal status
- Telegram initData verification

Never ask users for seed phrases or private keys.

Future real-token launch:
publish a clear snapshot and conversion rule first, then distribute the real VLX token to eligible users. Do not promise price or exchange listing before it exists.
