import 'dotenv/config';
import express from 'express';
import Database from 'better-sqlite3';
import {Telegraf} from 'telegraf';
import crypto from 'crypto';
import path from 'path';
import {fileURLToPath} from 'url';

const __dirname=path.dirname(fileURLToPath(import.meta.url));
const app=express(),db=new Database('veltrix.db'),bot=new Telegraf(process.env.BOT_TOKEN);
const PORT=Number(process.env.PORT||3000), RATE=Number(process.env.MINING_PER_HOUR||4.57);
const REF=Number(process.env.REFERRAL_BONUS||25), MIN=Number(process.env.WITHDRAW_MIN||500), ADMIN=String(process.env.ADMIN_ID||'');
const now=()=>Math.floor(Date.now()/1000);

db.exec(`CREATE TABLE IF NOT EXISTS users(
id INTEGER PRIMARY KEY,username TEXT,first_name TEXT,balance REAL DEFAULT 0,rate REAL DEFAULT 4.57,
last_update INTEGER,wallet TEXT,referred_by INTEGER,created_at INTEGER);
CREATE TABLE IF NOT EXISTS withdrawals(
id INTEGER PRIMARY KEY AUTOINCREMENT,user_id INTEGER,amount REAL,wallet TEXT,status TEXT DEFAULT 'PENDING',created_at INTEGER);`);

const get=u=>db.prepare('SELECT * FROM users WHERE id=?').get(Number(u));
function create(tg,ref){
 let u=get(tg.id); if(u)return u;
 let r=Number(ref)||null;if(r===Number(tg.id)||!get(r))r=null;
 db.prepare(`INSERT INTO users VALUES(?,?,?,?,?,?,?,?,?)`).run(tg.id,tg.username||'',tg.first_name||'',0,RATE,now(),'',r,now());
 if(r)db.prepare('UPDATE users SET balance=balance+? WHERE id=?').run(REF,r);
 return get(tg.id);
}
function accrue(u){
 const t=now(),e=Math.max(0,t-u.last_update)*u.rate/3600;
 db.prepare('UPDATE users SET balance=balance+?,last_update=? WHERE id=?').run(e,t,u.id);
 return get(u.id);
}
function pub(u){u=accrue(u);return{id:u.id,username:u.username,firstName:u.first_name,balance:+u.balance.toFixed(6),rate:+u.rate.toFixed(6),wallet:u.wallet||'',minWithdraw:MIN};}

function verify(initData){
 if(!initData)return null;const p=new URLSearchParams(initData),hash=p.get('hash');if(!hash)return null;p.delete('hash');
 const data=[...p.entries()].sort(([a],[b])=>a.localeCompare(b)).map(([k,v])=>`${k}=${v}`).join('\n');
 const secret=crypto.createHmac('sha256','WebAppData').update(process.env.BOT_TOKEN).digest();
 const calc=crypto.createHmac('sha256',secret).update(data).digest('hex');
 if(calc.length!==hash.length||!crypto.timingSafeEqual(Buffer.from(calc),Buffer.from(hash)))return null;
 if(now()-Number(p.get('auth_date')||0)>86400)return null;
 return JSON.parse(p.get('user')||'null');
}
function auth(req,res){const t=verify(req.body?.initData);if(!t){res.status(401).json({error:'Invalid Telegram session'});return null}return t}

app.use(express.json());app.use(express.static(path.join(__dirname,'web')));
app.get('/api/config',(_,r)=>r.json({name:'VELTRIX',ticker:'VLX',rate:RATE,referral:REF,minWithdraw:MIN}));
app.post('/api/user',(req,res)=>{const t=verify(req.body?.initData);if(!t)return res.status(401).json({error:'Invalid Telegram session'});res.json(pub(create(t,req.body?.startParam)));});
app.post('/api/claim',(req,res)=>{const t=auth(req,res);if(t)res.json({ok:true,user:pub(get(t.id))});});
app.post('/api/boost',(req,res)=>{const t=auth(req,res);if(!t)return;const u=accrue(get(t.id));db.prepare('UPDATE users SET rate=rate+0.5 WHERE id=?').run(u.id);res.json({ok:true,user:pub(get(u.id))});});
app.post('/api/wallet',(req,res)=>{const t=auth(req,res);if(!t)return;const w=String(req.body?.wallet||'').trim();if(w.length<20||w.length>200)return res.status(400).json({error:'Invalid wallet address'});db.prepare('UPDATE users SET wallet=? WHERE id=?').run(w,t.id);res.json({ok:true,user:pub(get(t.id))});});
app.post('/api/withdraw',(req,res)=>{const t=auth(req,res);if(!t)return;const n=Number(req.body?.amount),u=accrue(get(t.id));
 if(!Number.isFinite(n)||n<MIN)return res.status(400).json({error:`Minimum withdrawal is ${MIN} VLX Points`});
 if(!u.wallet)return res.status(400).json({error:'Save your wallet first'});
 if(n>u.balance)return res.status(400).json({error:'Insufficient VLX Points'});
 db.prepare('UPDATE users SET balance=balance-? WHERE id=?').run(n,u.id);
 const x=db.prepare('INSERT INTO withdrawals(user_id,amount,wallet,status,created_at) VALUES(?,?,?,?,?)').run(u.id,n,u.wallet,'PENDING',now());
 res.json({ok:true,id:x.lastInsertRowid,user:pub(get(u.id))});
});
app.get('/api/admin/withdrawals',(req,res)=>{if(String(req.query.adminId)!==ADMIN)return res.status(403).json({error:'Forbidden'});res.json(db.prepare(`SELECT w.*,u.username,u.first_name FROM withdrawals w JOIN users u ON u.id=w.user_id ORDER BY w.id DESC LIMIT 200`).all());});
app.post('/api/admin/status',(req,res)=>{if(String(req.body?.adminId)!==ADMIN)return res.status(403).json({error:'Forbidden'});if(!['PENDING','APPROVED','REJECTED','PAID'].includes(req.body.status))return res.status(400).json({error:'Bad status'});db.prepare('UPDATE withdrawals SET status=? WHERE id=?').run(req.body.status,Number(req.body.id));res.json({ok:true});});

bot.start(ctx=>{const url=process.env.APP_URL;ctx.reply('⚡ VELTRIX (VLX)\\n\\n⛏️ Mine VLX Points and invite friends!\\n\\n⚠️ Points are currently off-chain and have no guaranteed monetary value.',url?{reply_markup:{inline_keyboard:[[{text:'⛏️ OPEN VELTRIX MINER',web_app:{url}}]]}}:{});});
bot.command('id',ctx=>ctx.reply(`Telegram ID: ${ctx.from.id}`));
bot.launch();app.listen(PORT,()=>console.log(`VELTRIX Mini App on ${PORT}`));
